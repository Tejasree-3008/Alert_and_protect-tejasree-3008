import React, { useEffect, useState } from "react";
import axios from "axios";

function AlertList() {
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/alerts")
      .then(res => setAlerts(res.data));
  }, []);

  return (
    <div>
      <h2>Fraud Alerts</h2>
      <ul>
        {alerts.map(alert => (
          <li key={alert.id}>
            ⚠ {alert.message}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default AlertList;
