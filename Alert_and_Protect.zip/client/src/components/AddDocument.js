import React, { useState } from "react";
import axios from "axios";

function AddDocument() {
  const [type, setType] = useState("");
  const [number, setNumber] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:5000/add", { type, number });
    alert("Document Added!");
  };

  return (
    <div>
      <h2>Add Government Document</h2>
      <form onSubmit={handleSubmit}>
        <input
          placeholder="Document Type (PAN/Aadhaar)"
          value={type}
          onChange={e => setType(e.target.value)}
        />
        <input
          placeholder="Document Number"
          value={number}
          onChange={e => setNumber(e.target.value)}
        />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default AddDocument;
