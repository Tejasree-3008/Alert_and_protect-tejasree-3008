import React, { useEffect, useState } from "react";
import axios from "axios";

function Dashboard() {
  const [docs, setDocs] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/documents")
      .then(res => setDocs(res.data));
  }, []);

  return (
    <div>
      <h2>All Documents</h2>
      <ul>
        {docs.map(doc => (
          <li key={doc.id}>
            {doc.type} - {doc.number} - Risk: {doc.risk}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Dashboard;
