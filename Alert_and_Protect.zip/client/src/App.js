import React from "react";
import Dashboard from "./components/Dashboard";
import AddDocument from "./components/AddDocument";
import AlertList from "./components/AlertList";

function App() {
  return (
    <div style={{ fontFamily: "Arial", padding: "20px" }}>
      <h1>Fraud Loan Alert System</h1>
      <AddDocument />
      <Dashboard />
      <AlertList />
    </div>
  );
}

export default App;
