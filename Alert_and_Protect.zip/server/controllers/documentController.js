
const Document = require('../models/Document');

exports.addDocument = async (req, res) => {
  const doc = await Document.create(req.body);
  res.json(doc);
};

exports.getDocuments = async (req, res) => {
  const docs = await Document.find();
  res.json(docs);
};
