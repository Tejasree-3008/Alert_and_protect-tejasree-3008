
const express = require('express');
const { addDocument, getDocuments } = require('../controllers/documentController');
const router = express.Router();

router.post('/', addDocument);
router.get('/', getDocuments);

module.exports = router;
